import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@Component({
  selector: 'app-build-new-form3',
  templateUrl: './build-new-form3.component.html',
  styleUrls: ['./build-new-form3.component.css']
})
export class BuildNewForm3Component implements OnInit {

  invoiceForm: FormGroup;
  
  constructor(private _formBuild: FormBuilder) {  }
  
  ngOnInit() {
    this.invoiceForm = this._formBuild.group({
      Package_Title: [''],
      HotelData: this._formBuild.array([this.addRows()])
    });
  }
  
  addRows() {
    let group = this._formBuild.group({
      Htitle: [''],
      HDescription: [''],
      hotelStar: [],
      RoomData: this._formBuild.array([])
    });
    this.addRoom(group.controls.RoomData)
    return group;
  }
  
  addHotel() {
    const control: FormArray = this.invoiceForm.get(`HotelData`) as FormArray;
    control.push(this.addRows());
  }
  
  addRoom(hotel:any) {
    let group = this._formBuild.group({
      Hotel_Room_Type: ['']
    })
    hotel.push(group)
  }
  
  removeRooms(hotel, index) { 
    hotel.controls.RoomData.removeAt(index)
    
  }

}
