import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-lists',
  templateUrl: './form-lists.component.html',
  styleUrls: ['./form-lists.component.css']
})
export class FormListsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
