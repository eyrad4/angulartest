import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuildNewForm3Component } from './build-new-form3.component';

describe('BuildNewForm3Component', () => {
  let component: BuildNewForm3Component;
  let fixture: ComponentFixture<BuildNewForm3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuildNewForm3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuildNewForm3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
