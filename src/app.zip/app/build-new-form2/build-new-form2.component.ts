import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { ElemetsService } from '../elemets.service';
import { SortablejsOptions } from 'angular-sortablejs';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-build-new-form2',
  templateUrl: './build-new-form2.component.html',
  styleUrls: ['./build-new-form2.component.css'],  
})
export class BuildNewForm2Component implements OnInit {

  @ViewChild('form') form: NgForm;
  elements = []; //это наш сервис с данными
  @Input() newElements = [];
  find = Object;
  newForm = []; //это наш массив с новыми данными, которые мы береме с сервиса
  

  constructor(private service: ElemetsService) {}

  addElement(event){
    //ищем элемент в нашем сервисе
    this.find =  this.elements.find(element => element.name == event.target.innerText);
    
    //добавляем найденый элемент в новый массив массив
   // this.newForm.push(this.find);
    this.newForm.push(Object.assign({}, this.find));
    //copy = event.target.innerText;
    //console.log(this.newForm);
    //console.log(this.elements);
  }

  //метод который будет удалять определенный элемент с формы
  deleteElement(index){
    console.log(index);
    this.newForm.splice(index, 1);
  }

  //метод который будет редактировать данные элемента
  editElement(index){
    console.log(index);


  }

  //добавляем поле для динамических обьектов селекта
  addField(index){
    this.newForm[index].options.push({value: ''});
    //console.log(this.newForm[index]);
  }

  //добавляем метод который будет удалять динамических обьектов селекта
  deleteField(index){
    this.newForm[index].options.splice(index, 1);
  }


  //метод который будет сохранять изменения в элементе формы
  saveElement(value: any, index){
    //console.log(value);
    //console.log(this.form);
    
   this.newForm[index]['label'] = value.label;
   this.newForm[index]['placeholder'] = value.placeholder;  
   this.newForm[index]['required'] = value.required;
   if(value.options != ''){
    //this.newForm[index]['options'] = value.options; 
    console.log(value);
   }  
    //console.log(this.newForm); 
    //this.newForm[index].options = this.form.value.placeholder;    
    
    
    //console.log(index); 
    //console.log(this.form.value); 
  }

  //метод который сохранит данные формы в нашу псевдо базу json serv
  saveForm(){

  }

  ngOnInit() {
    this.elements = this.service.elements;      
  }

}
